import requests
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'  # Replace with a secure key
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///weather_app.db'  # SQLite database path
db = SQLAlchemy(app)  # Initialize SQLAlchemy with the app

# Initialize Flask-Login
login_manager = LoginManager(app)
login_manager.login_view = 'login'  # Define the login view for login required redirects

# Define User model with SQLAlchemy and UserMixin for authentication
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)

# Define SavedCities model to store user's saved cities
class SavedCity(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    city_name = db.Column(db.String(150), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)  # Foreign key to User table
    user = db.relationship('User', backref=db.backref('saved_cities', lazy=True))

# Load user function for Flask-Login
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))  # Load user by ID

# Fetch weather function
def get_weather(city_name):
    api_key = "4aebdfb9fb4f4e0f2e63804d1a4a6628"
    base_url = "http://api.openweathermap.org/data/2.5/weather"
    params = {
        'q': city_name,
        'appid': api_key,
        'units': 'metric'
    }
    response = requests.get(base_url, params=params)
    if response.status_code == 200:
        data = response.json()
        print(f"Weather data for {city_name}: {data}")  # Debugging line
        return data
    else:
        print(f"Failed to fetch weather data for {city_name}")  # Debugging line
        return None


# Root route redirects to login
@app.route('/')
def index():
    return redirect(url_for('login'))

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username, password=password).first()  # Query user
        if user:
            login_user(user)  # Log the user in
            return redirect(url_for('dashboard'))
        else:
            flash('Login Failed. Check your username and/or password.')  # Flash message for failed login
    return render_template('login.html')  # Render login template

# Register route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if User.query.filter_by(username=username).first():  # Check if user exists
            flash('Username already exists.')  # Flash message for existing user
        else:
            new_user = User(username=username, password=password)  # Create new user
            db.session.add(new_user)  # Add new user to the session
            db.session.commit()  # Commit changes
            login_user(new_user)  # Log the new user in
            return redirect(url_for('dashboard'))
    return render_template('register.html')  # Render register template

# Dashboard route (requires login)
@app.route('/dashboard', methods=['GET', 'POST'])
@login_required
def dashboard():
    weather_data = None
    if request.method == 'POST':
        city_name = request.form['city']
        weather_data = get_weather(city_name)  # Fetch weather data
        if not weather_data:
            flash('Could not fetch weather data for the specified city.')  # Flash message for failed fetch
    return render_template('dashboard.html', weather=weather_data)  # Render dashboard template with weather data

# Save city route
@app.route('/save_city/<city_name>', methods=['POST'])
@login_required
def save_city(city_name):
    existing_city = SavedCity.query.filter_by(city_name=city_name, user_id=current_user.id).first()
    if not existing_city:
        new_city = SavedCity(city_name=city_name, user_id=current_user.id)
        db.session.add(new_city)
        db.session.commit()
        flash(f'{city_name} has been saved.')
    else:
        flash(f'{city_name} is already saved.')
    return redirect(url_for('dashboard'))


# My Cities route
@app.route('/my_cities')
@login_required
def my_cities():
    saved_cities = SavedCity.query.filter_by(user_id=current_user.id).all()
    print(f"Saved Cities: {saved_cities}")  # Fetch saved cities for the current user
    weather_data = [get_weather(city.city_name) for city in saved_cities]  # Get weather for each saved city
    return render_template('my_cities.html', saved_cities=weather_data)  # Pass weather data to the template

# Unsave city route
@app.route('/unsave_city/<city_name>')
@login_required
def unsave_city(city_name):
    city = SavedCity.query.filter_by(city_name=city_name, user_id=current_user.id).first()
    if city:
        db.session.delete(city)
        db.session.commit()
        flash(f'{city_name} has been removed from your saved cities.')
    return redirect(url_for('my_cities'))

# About route
@app.route('/about')
def about():
    return render_template('about.html')  # Render the about page

# Account route
@app.route('/account')
@login_required
def account():
    return render_template('account.html')  # Render the account page

# Logout route
@app.route('/logout')
@login_required
def logout():
    logout_user()  # Logs the user out
    flash('You have been logged out successfully.')  # Flash message for successful logout
    return redirect(url_for('login'))  # Redirect to login page after logout

# Run the app
if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Create database tables within the application context
    app.run(debug=True)  # Run the Flask app in debug mode
